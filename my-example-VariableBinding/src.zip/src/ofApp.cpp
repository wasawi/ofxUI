#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup()
{
    
	position = ofPoint(ofGetWidth()*.5, ofGetHeight()*.5);
	gui = new ofxUISuperCanvas("Circle position");
	
	
	// this is what i was doing before
	gui->add2DPad("FRONT_XYZ", ofPoint(0, ofGetWidth()), ofPoint(0, ofGetHeight()), ofPoint(position.x,position.y));
	gui->add2DPad("TOP_XZY"	 , ofPoint(0, ofGetWidth()), ofPoint(0, ofGetHeight()), ofPoint(position.x,position.z));
	gui->add2DPad("RIGHT_ZYX", ofPoint(0, ofGetWidth()), ofPoint(0, ofGetHeight()), ofPoint(position.z,position.y));
	// and then refreshing the pads and the variable after every event
	
	/* this is what I "intuitively" would like to do:
	 position_XYZ	=	ofVec3f(&position.x, &position.y, &position.z);
	 position_XZY	=	ofVec3f(&position.x, &position.z, &position.y);
	 position_ZYX	=	ofVec3f(&position.z, &position.y, &position.x);
	 
	 gui->add2DPad("FRONT_XYZ", ofPoint(0, ofGetWidth()), ofPoint(0, ofGetHeight()), position_XYZ);
	 gui->add2DPad("TOP_XZY"	 , ofPoint(0, ofGetWidth()), ofPoint(0, ofGetHeight()), position_XZY);
	 gui->add2DPad("RIGHT_ZYX", ofPoint(0, ofGetWidth()), ofPoint(0, ofGetHeight()), position_ZYX);
	 */
	
	gui->autoSizeToFitWidgets();
	ofAddListener(gui->newGUIEvent,this,&ofApp::guiEvent);

}

//--------------------------------------------------------------
void ofApp::draw()
{    	
	ofBackground(50);
	ofSetColor(200);
	ofPushView();
		ofTranslate(ofVec3f(0,0,-ofGetWidth()));
		ofCircle(position, 50);
	ofPopView();
}
//--------------------------------------------------------------
void ofApp::guiEvent(ofxUIEventArgs &e)
{

	string name = e.widget->getName(); 
	int kind = e.widget->getKind();
	
	if (name== "FRONT_XYZ")
	{
		ofxUI2DPad *pad = (ofxUI2DPad *) gui->getWidget("FRONT_XYZ");
		
		// get values
		position.x = pad->getScaledValue().x;
		position.y = pad->getScaledValue().y;
		updatePads();
	}
	else if (name== "TOP_XZY")
	{
		ofxUI2DPad *pad = (ofxUI2DPad *) gui->getWidget("TOP_XZY");
		
		// get values
		position.x = pad->getScaledValue().x;
		position.z = pad->getScaledValue().y;
		updatePads();
	}
	else if (name== "RIGHT_ZYX")
	{
		ofxUI2DPad *pad = (ofxUI2DPad *) gui->getWidget("RIGHT_ZYX");
		
		// get values
		position.z = pad->getScaledValue().x;
		position.y = pad->getScaledValue().y;
		updatePads();
	}

	
}

//--------------------------------------------------------------
void ofApp::updatePads()
{
	//update pads
	ofxUI2DPad *pad;
	pad = (ofxUI2DPad *) gui->getWidget("FRONT_XYZ");
	pad -> setValue(ofVec3f(position.x, position.y, 0));
	pad = (ofxUI2DPad *) gui->getWidget("TOP_XZY");
	pad -> setValue(ofVec3f(position.x,position.z,0));
	pad = (ofxUI2DPad *) gui->getWidget("RIGHT_ZYX");
	pad -> setValue(ofVec3f(position.z,position.y,0));
}

//--------------------------------------------------------------
void ofApp::exit()
{
    delete gui; 
}

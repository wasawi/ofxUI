#pragma once 

#include "ofMain.h"
#include "ofxUI.h"

class ofApp : public ofBaseApp 
{
	public:
	void setup();
	void draw();
	void exit(); 

	void updatePads();
	ofxUISuperCanvas *gui;
	void guiEvent(ofxUIEventArgs &e);
   
	ofVec3f position;
	ofVec3f* position_XYZ;
	ofVec3f* position_XZY;
	ofVec3f* position_ZYX;
};
